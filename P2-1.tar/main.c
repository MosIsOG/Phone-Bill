#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "bill.h"

int main(int argc, char *argv[])
{
    // Check if the correct number of command-line arguments is provided
    if (argc != 3)
    {
        fprintf(stderr, "Incorrect number of arguments.\n");
        fprintf(stderr, "USAGE: ./%s <input_file> <output_file>\n", argv[0]);
        return 1; // Exit the program with an error code
    }

    // Open the input and output files
    FILE *in = fopen(argv[1], "r"); // Open input file in read mode
    FILE *out = fopen(argv[2], "w"); // Open output file in write mode
    FILE *readBill = NULL; // File pointer for reading bill data from a file
    int record = 0; // Variable to keep track of the number of records processed
    char cmd[10]; // Array to store the command read from the input file
    struct Bill b; // Structure to store bill data

    // Read the first command from the input file
    fscanf(in, "%s", cmd);

    // Loop until the end of the input file is reached
    while (!feof(in))
    {
        // Ignore comments (lines starting with '#')
        if (cmd[0] == '#')
        {
            fscanf(in, "%*[^\n]\n"); // Skip the current line
        }

        // Check the command type and perform corresponding actions
        if (cmd[0] == 'l') // If the command is 'l' for reading bill data
        {
            record = read_bill(in, out, readBill, &b, record); // Read bill data and update the record count
        }
        else if (cmd[0] == 'a') // If the command is 'a' for calculating average
        {
            average(&b, in, out, record); // Calculate and output average
        }
        else if (cmd[0] == 's') // If the command is 's' for summarizing data
        {
            summarize(&b, in, out, record); // Summarize and output data
        }
        else if (cmd[0] == 'd') // If the command is 'd' for displaying data
        {
            display(&b, out, record); // Display data
        }

        fscanf(in, "%s", cmd); // Read the next command from the input file
    }

    // Close the input and output files
    fclose(in);
    fclose(out);

    return 0; // Exit the program successfully
}
