#include <stdio.h>




struct Bill
{
    char* name;
    char* address;
    struct CallRecord* calls;
    int len;
    int filled;
    char* temp1;
    char* temp2;
    
};
struct ProcessedMonth {
    char *name;
    int processed;
};

struct CallRecord
{
    int year;
    int month;
    int day;
    int pnum1;
    int pnum2;
    int pnum3;
    int tcall;
    int duration;
    double cost;
};
struct Average 
{
    int iStrMonth;
    double avgCost;
    double avgDrtn;
    int cnt;
};

int read_bill(FILE* in, FILE* out, FILE* readBill, struct Bill* b, int record);
void average(struct Bill* b, FILE* out, FILE* in, int record);
void read_costAndDrtn(struct Bill* b, FILE*readBill, int idx);
int compareCalls(const void *a, const void *b);
char *getMonthName(int monthNumber);
void read_date(struct Bill* b,FILE* readBill,int idx);
void computeAverage(struct Bill* b, int idx, struct Average* a);
char *convertToMonth(struct Bill *b, int idx, struct Average *a);
void read_phone(struct Bill* b, FILE* readBill, int idx);
void summarize(struct Bill* b, FILE* in, FILE* out, int record);
void display(struct Bill *b, FILE *out, int record);
